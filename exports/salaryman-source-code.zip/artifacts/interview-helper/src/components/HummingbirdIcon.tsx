type Props = {
  size?: number;
  color?: string;
  className?: string;
  style?: React.CSSProperties;
};

// Hummingbird silhouette by Lorc / GameIcons.net (CC BY 3.0)
// https://game-icons.net/1x1/lorc/hummingbird.html
export function HummingbirdIcon({ size = 16, color = "currentColor", className, style }: Props) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 512 512"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={style}
      aria-label="hummingbird"
    >
      <path
        fill={color}
        d="M139.7 23.52c-9.1 30.54-16.5 61.64-12.7 91.58c4.2 32.7 21 64.9 65.7 95.7c-53.6 74.8-86.1 204.4-59.3 277.7c10.9-54 14.2-97.8 53.5-144.6c77.5-25.6 123.9-37.6 140.3-125.7c6.2-14.7 12.6-19.3 31.9-24.7c10.6-2.9 22.2-7.5 22.1-19.2c-.2-49.3-28.3-68.4-57.6-67.9c-29.4.5-60 20.6-65.4 49.8c-6 1.8-11.9 4.5-17.7 8c-62.9-43.7-82.1-85.86-100.8-140.68M32.03 107c10.8 27.2 26.44 54.6 49.2 76.1c24.27 22.9 56.47 39.3 100.87 42.2c-34.5-24.2-54.8-50.3-65.2-77.2c-29.4-10.9-56.47-25-84.87-41.1m300.07 26.3a12.24 12.24 0 0 1 12.2 12.2a12.24 12.24 0 0 1-12.2 12.2a12.24 12.24 0 0 1-12.2-12.2a12.24 12.24 0 0 1 12.2-12.2m60 56.1c-3.5 5.1-7.1 10.2-16.1 13.2c33.9 25.3 79.1 76.5 104 105c-11.2-33.2-55.8-88.6-87.9-118.2"
      />
    </svg>
  );
}

export default HummingbirdIcon;
